cd pages
node index.js
echo "Proxy Is Running"